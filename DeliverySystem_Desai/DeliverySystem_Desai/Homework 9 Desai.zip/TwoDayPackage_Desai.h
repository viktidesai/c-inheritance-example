#pragma once
class TwoDayPackage_Desai:public Package_Desai
{
public:
	TwoDayPackage_Desai();
	double costtwo;
	void calculateCost();

};

