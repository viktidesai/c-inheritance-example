#pragma once
class Overnight_Desai:public Package_Desai
{
public:
		double costovnt;
	void calculateCost();
};

