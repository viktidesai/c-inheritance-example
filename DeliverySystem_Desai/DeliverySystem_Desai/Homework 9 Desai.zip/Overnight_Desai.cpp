#include "stdafx.h"
#include "Package_Desai.h"
#include "Overnight_Desai.h"
#include <iostream>
using namespace std;






void Overnight_Desai::calculateCost()
{
	costovnt = 5 * weight;
	cout << costovnt<<" $ "<<endl;
}