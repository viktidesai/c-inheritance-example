#pragma once
class Package_Desai //Class Package 
{
public:
	double coststd;   //function declaration
	int weight;         

	Package_Desai();
	void calculateCost();
	void dispinfo();
	void setweight(int);
	
};

